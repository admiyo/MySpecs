package com.titan.test;

import org.junit.Test;
import com.titan.clients.InnerJoin;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public class TestSmoke {

    @Test
    public void testSmoke() throws Exception
    {
        InnerJoin.main(null);
    }
}
