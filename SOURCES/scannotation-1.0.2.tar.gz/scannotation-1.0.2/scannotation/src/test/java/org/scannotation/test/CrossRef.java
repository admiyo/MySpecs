package org.scannotation.test;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public class CrossRef implements InterfaceWithParameterAnnotations
{
   public void junk(int param)
   {
   }
}
