package org.xnap.commons.i18n.testpackage.resources;

public class HasItsOwnResources 
{

}
