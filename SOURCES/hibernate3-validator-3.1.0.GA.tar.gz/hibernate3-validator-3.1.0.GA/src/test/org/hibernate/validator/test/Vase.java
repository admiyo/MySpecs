//$Id: Vase.java 15133 2008-08-20 10:05:57Z hardy.ferentschik $
package org.hibernate.validator.test;

/**
 * A vase has to be Serializable to fit in luggages
 *
 * @author Emmanuel Bernard
 */
@Serializability
public class Vase {
}
