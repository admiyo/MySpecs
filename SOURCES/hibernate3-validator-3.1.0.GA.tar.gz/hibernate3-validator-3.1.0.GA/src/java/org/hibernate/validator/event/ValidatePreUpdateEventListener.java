//$Id: ValidatePreUpdateEventListener.java 15133 2008-08-20 10:05:57Z hardy.ferentschik $
package org.hibernate.validator.event;

/**
 * Before update, execute the validator framework
 *
 * @deprecated use ValidateEventListener
 *
 * @author Gavin King
 */
public class ValidatePreUpdateEventListener extends ValidateEventListener {

}
