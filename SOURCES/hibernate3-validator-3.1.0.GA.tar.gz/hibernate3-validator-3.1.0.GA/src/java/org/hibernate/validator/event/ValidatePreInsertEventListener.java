//$Id: ValidatePreInsertEventListener.java 15133 2008-08-20 10:05:57Z hardy.ferentschik $
package org.hibernate.validator.event;

/**
 * Before insert, execute the validator framework
 *
 * @deprecated use ValidateEventListener
 * 
 * @author Gavin King
 */
public class ValidatePreInsertEventListener extends ValidateEventListener {

}
