This directory is part of Commons Build and is included automatically using svn:externals by components.

See http://svn.apache.org/viewcvs.cgi/jakarta/commons/proper/commons-build/trunk/
